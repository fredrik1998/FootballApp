/*! Select2 4.0.13 | https://github.com/select2/select2/blob/master/LICENSE.md */

!(function () {
  if (jQuery && jQuery.fn && jQuery.fn.select2 && jQuery.fn.select2.amd)
    var n = jQuery.fn.select2.amd;
  n.define("select2/i18n/sv", [], function () {
    return {
      errorLoading: function () {
        return "Resultat kunde inte laddas.";
      },
      inputTooLong: function (n) {
        return "Vänligen sudda ut " + (n.input.length - n.maximum) + " tecken";
      },
      inputTooShort: function (n) {
        return (
          "Vänligen skriv in " +
          (n.minimum - n.input.length) +
          " eller fler tecken"
        );
      },
      loadingMore: function () {
        return "Laddar fler resultat…";
      },
      maximumSelected: function (n) {
        return "Du kan max välja " + n.maximum + " element";
      },
      noResults: function () {
        return "Inga träffar";
      },
      searching: function () {
        return "Söker…";
      },
      removeAllItems: function () {
        return "Ta bort alla objekt";
      },
    };
  }),
    n.define,
    n.require;
})();
